const firebaseConfig = {
    apiKey: "AIzaSyAnBQsZQd1hgZw8Vxzu-tdjHzKE2cxQShs",
    authDomain: "bitchcup.firebaseapp.com",
    projectId: "bitchcup",
    storageBucket: "bitchcup.firebasestorage.app",
    messagingSenderId: "369068773771",
    appId: "1:369068773771:web:a678b40c7fd857e74a5f8e",
    measurementId: "G-GGJ0SFVPCQ"
  };